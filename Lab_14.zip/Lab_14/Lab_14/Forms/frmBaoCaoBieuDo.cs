using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Lab_14;
using Lab_14.Reports;
using Lab_14.DAL;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using CrystalDecisions.Windows.Forms;

namespace Lab_14.Forms
{
    /// <summary>
    /// Bài 8: Báo cáo có biểu đồ qua Crystal Reports
    /// Hiển thị báo cáo chứa biểu đồ số lượng sinh viên theo khoa trên CrystalReportViewer
    /// </summary>
    public partial class frmBaoCaoBieuDo : Form
    {
        private ReportDocument _report;
        private CrystalReportViewer crystalReportViewer1;
        private Button btnXemBaoCao;
        private Button btnXuatPdf;
        private Button btnXuatExcel;
        private Button btnClose;
        private BaoCaoDAL _dal = new BaoCaoDAL();

        public frmBaoCaoBieuDo()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Báo cáo có biểu đồ";
            this.Size = new Size(1100, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Maximized;

            // === Panel Bottom ===
            Panel pnlButtons = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                Padding = new Padding(10)
            };

            btnXemBaoCao = new Button
            {
                Text = "Xem báo cáo",
                Size = new Size(130, 35),
                Location = new Point(10, 8),
                BackColor = Color.FromArgb(30, 136, 229),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnXemBaoCao.Click += delegate { LoadReport(); };

            btnXuatPdf = new Button
            {
                Text = "Xuất PDF",
                Size = new Size(120, 35),
                Location = new Point(150, 8),
                BackColor = Color.SteelBlue,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnXuatPdf.Click += btnXuatPdf_Click;

            btnXuatExcel = new Button
            {
                Text = "Xuất Excel",
                Size = new Size(120, 35),
                Location = new Point(280, 8),
                BackColor = Color.FromArgb(46, 125, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnXuatExcel.Click += btnXuatExcel_Click;

            btnClose = new Button
            {
                Text = "Đóng",
                Size = new Size(120, 35),
                Location = new Point(410, 8),
                BackColor = Color.Gray,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnClose.Click += delegate { this.Close(); };

            pnlButtons.Controls.AddRange(new Control[] { btnXemBaoCao, btnXuatPdf, btnXuatExcel, btnClose });

            // === CrystalReportViewer ===
            crystalReportViewer1 = new CrystalReportViewer
            {
                Dock = DockStyle.Fill,
                ShowGroupTreeButton = true,
                ToolPanelView = ToolPanelViewType.None
            };

            this.Controls.Add(crystalReportViewer1);
            this.Controls.Add(pnlButtons);

            this.Load += (s, e) => LoadReport();
        }

        private void LoadReport()
        {
            try
            {
                DataTable data = _dal.GetStudentReportData();

                if (_report != null)
                {
                    _report.Close();
                    _report.Dispose();
                    _report = null;
                }

                try
                {
                    _report = new rptBieuDo();
                }
                catch
                {
                    try
                    {
                        _report = new rptSinhVien();
                    }
                    catch { }
                }

                if (_report == null || _report.Database.Tables.Count == 0)
                {
                    string[] searchPaths = new string[]
                    {
                        Path.Combine(Application.StartupPath, @"Reports\rptBieuDo.rpt"),
                        Path.Combine(Application.StartupPath, "rptBieuDo.rpt"),
                        Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\Reports\rptBieuDo.rpt"),
                        Path.Combine(Application.StartupPath, @"Reports\rptSinhVien.rpt"),
                        Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\Reports\rptSinhVien.rpt")
                    };

                    foreach (string path in searchPaths)
                    {
                        if (File.Exists(path))
                        {
                            try
                            {
                                ReportDocument doc = new ReportDocument();
                                doc.Load(path);
                                if (doc.Database.Tables.Count > 0)
                                {
                                    if (_report != null) { _report.Close(); _report.Dispose(); }
                                    _report = doc;
                                    break;
                                }
                                else if (_report == null)
                                {
                                    _report = doc;
                                }
                                else
                                {
                                    doc.Close();
                                    doc.Dispose();
                                }
                            }
                            catch { }
                        }
                    }
                }

                if (_report == null || _report.Database.Tables.Count == 0)
                {
                    MessageBox.Show(
                        "Báo cáo 'rptBieuDo.rpt' chưa có bảng dữ liệu (0 tables).\n\n" +
                        "Hướng dẫn gắn bảng trong Visual Studio:\n" +
                        "1. Mở file rptBieuDo.rpt trong Visual Studio\n" +
                        "2. Nhấp chuột phải -> Database -> Database Expert...\n" +
                        "3. Thêm bảng hoặc view (vw_BaoCaoSinhVien) vào mục 'Selected Tables' -> bấm OK\n" +
                        "4. Kéo các trường vào báo cáo và nhấn Ctrl + S để lưu lại.",
                        "Thông báo cấu hình báo cáo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string rptTable = _report.Database.Tables[0].Name;
                if (!string.IsNullOrEmpty(rptTable) && data.TableName != rptTable)
                {
                    data.TableName = rptTable;
                }

                _report.SetDataSource(data);
                crystalReportViewer1.ReportSource = _report;
                crystalReportViewer1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải báo cáo biểu đồ: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXuatPdf_Click(object sender, EventArgs e)
        {
            if (_report == null)
            {
                MessageBox.Show("Chưa có báo cáo để xuất. Hãy bấm Xem báo cáo trước.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Filter = "PDF file|*.pdf";
                dlg.FileName = "BaoCaoBieuDo.pdf";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    _report.ExportToDisk(ExportFormatType.PortableDocFormat, dlg.FileName);
                    MessageBox.Show("Đã xuất PDF thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnXuatExcel_Click(object sender, EventArgs e)
        {
            if (_report == null)
            {
                MessageBox.Show("Chưa có báo cáo để xuất. Hãy bấm Xem báo cáo trước.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Filter = "Excel Workbook|*.xls";
                dlg.FileName = "BaoCaoBieuDo.xls";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    _report.ExportToDisk(ExportFormatType.ExcelWorkbook, dlg.FileName);
                    MessageBox.Show("Đã xuất Excel thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            if (_report != null)
            {
                _report.Close();
                _report.Dispose();
                _report = null;
            }
            base.OnFormClosed(e);
        }
    }
}
