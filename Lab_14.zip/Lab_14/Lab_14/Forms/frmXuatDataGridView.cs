using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Lab_14.DAL;

namespace Lab_14.Forms
{
    /// <summary>
    /// Bài 9: Xuất DataGridView sang Excel
    /// Xuất tập dữ liệu đang lọc; giữ tiêu đề cột, định dạng ngày và số
    /// </summary>
    public partial class frmXuatDataGridView : Form
    {
        private DataGridView dgvData;
        private ComboBox cboKhoa;
        private Button btnLocDuLieu;
        private Button btnXuatExcel;
        private Button btnClose;
        private BaoCaoDAL _dal = new BaoCaoDAL();

        public frmXuatDataGridView()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Xuất DataGridView sang Excel";
            this.Size = new Size(1100, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Maximized;

            // === Panel Top ===
            Panel pnlTop = new Panel
            {
                Dock = DockStyle.Top,
                Height = 60,
                Padding = new Padding(10),
                BackColor = Color.FromArgb(240, 244, 248)
            };

            Label lblKhoa = new Label
            {
                Text = "Lọc theo khoa:",
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                Location = new Point(15, 18),
                AutoSize = true
            };

            cboKhoa = new ComboBox
            {
                Location = new Point(130, 15),
                Size = new Size(280, 30),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10F)
            };

            btnLocDuLieu = new Button
            {
                Text = "Lọc dữ liệu",
                Size = new Size(120, 35),
                Location = new Point(430, 12),
                BackColor = Color.FromArgb(30, 136, 229),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnLocDuLieu.Click += btnLocDuLieu_Click;

            pnlTop.Controls.AddRange(new Control[] { lblKhoa, cboKhoa, btnLocDuLieu });

            // === Panel Bottom ===
            Panel pnlButtons = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                Padding = new Padding(10)
            };

            btnXuatExcel = new Button
            {
                Text = "Xuất Excel",
                Size = new Size(130, 35),
                Location = new Point(10, 8),
                BackColor = Color.FromArgb(46, 125, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnXuatExcel.Click += btnXuatExcel_Click;

            btnClose = new Button
            {
                Text = "Đóng",
                Size = new Size(120, 35),
                Location = new Point(150, 8),
                BackColor = Color.Gray,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnClose.Click += delegate { this.Close(); };

            pnlButtons.Controls.AddRange(new Control[] { btnXuatExcel, btnClose });

            // === DataGridView ===
            dgvData = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                BackgroundColor = Color.White,
                Font = new Font("Segoe UI", 9.5F),
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                    BackColor = Color.FromArgb(30, 136, 229),
                    ForeColor = Color.White,
                    Alignment = DataGridViewContentAlignment.MiddleCenter
                },
                EnableHeadersVisualStyles = false,
                AlternatingRowsDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.FromArgb(245, 247, 250)
                }
            };

            this.Controls.Add(dgvData);
            this.Controls.Add(pnlTop);
            this.Controls.Add(pnlButtons);

            this.Load += frmXuatDataGridView_Load;
        }

        private void frmXuatDataGridView_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable dtKhoa = _dal.GetDanhSachKhoa();
                DataRow drAll = dtKhoa.NewRow();
                drAll["MaKhoa"] = "ALL";
                drAll["TenKhoa"] = "-- Tất cả các khoa --";
                dtKhoa.Rows.InsertAt(drAll, 0);
                cboKhoa.DataSource = dtKhoa;
                cboKhoa.DisplayMember = "TenKhoa";
                cboKhoa.ValueMember = "MaKhoa";
            }
            catch { }

            LoadData("ALL");
        }

        private void LoadData(string maKhoa)
        {
            try
            {
                DataTable data;
                if (maKhoa == "ALL")
                    data = _dal.GetStudentReportData();
                else
                    data = _dal.GetStudentsByDepartment(maKhoa);

                dgvData.DataSource = data;

                if (dgvData.Columns.Contains("MaSV")) dgvData.Columns["MaSV"].HeaderText = "Mã SV";
                if (dgvData.Columns.Contains("HoTen")) dgvData.Columns["HoTen"].HeaderText = "Họ và tên";
                if (dgvData.Columns.Contains("NgaySinh"))
                {
                    dgvData.Columns["NgaySinh"].HeaderText = "Ngày sinh";
                    dgvData.Columns["NgaySinh"].DefaultCellStyle.Format = "dd/MM/yyyy";
                }
                if (dgvData.Columns.Contains("GioiTinh")) dgvData.Columns["GioiTinh"].HeaderText = "Giới tính";
                if (dgvData.Columns.Contains("TenKhoa")) dgvData.Columns["TenKhoa"].HeaderText = "Tên khoa";
                if (dgvData.Columns.Contains("DiemTB"))
                {
                    dgvData.Columns["DiemTB"].HeaderText = "Điểm TB";
                    dgvData.Columns["DiemTB"].DefaultCellStyle.Format = "N2";
                    dgvData.Columns["DiemTB"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                }
                if (dgvData.Columns.Contains("Email")) dgvData.Columns["Email"].HeaderText = "Email";
                if (dgvData.Columns.Contains("MaKhoa")) dgvData.Columns["MaKhoa"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLocDuLieu_Click(object sender, EventArgs e)
        {
            string maKhoa = cboKhoa.SelectedValue?.ToString() ?? "ALL";
            LoadData(maKhoa);
        }

        private void btnXuatExcel_Click(object sender, EventArgs e)
        {
            if (dgvData.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu để xuất.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Filter = "Excel Files|*.xls;*.xlsx|CSV Files|*.csv";
                dlg.FileName = "DanhSachSinhVien.xls";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        using (StreamWriter sw = new StreamWriter(dlg.FileName, false, System.Text.Encoding.UTF8))
                        {
                            sw.Write("<html><head><meta charset='utf-8'></head><body>");
                            sw.Write("<table border='1' cellspacing='0' cellpadding='4'>");

                            // Tiêu đề cột
                            sw.Write("<tr style='background-color:#1E88E5;color:white;font-weight:bold'>");
                            for (int i = 0; i < dgvData.Columns.Count; i++)
                            {
                                if (dgvData.Columns[i].Visible)
                                {
                                    sw.Write("<th>" + dgvData.Columns[i].HeaderText + "</th>");
                                }
                            }
                            sw.Write("</tr>");

                            // Dữ liệu từng dòng
                            foreach (DataGridViewRow row in dgvData.Rows)
                            {
                                if (row.IsNewRow) continue;
                                sw.Write("<tr>");
                                for (int i = 0; i < dgvData.Columns.Count; i++)
                                {
                                    if (!dgvData.Columns[i].Visible) continue;

                                    object val = row.Cells[i].Value;
                                    string cellValue = "";

                                    if (val is DateTime dt)
                                    {
                                        cellValue = dt.ToString("dd/MM/yyyy");
                                    }
                                    else if (val is decimal || val is double || val is float)
                                    {
                                        cellValue = string.Format("{0:N2}", val);
                                    }
                                    else
                                    {
                                        cellValue = val?.ToString() ?? "";
                                    }

                                    sw.Write("<td>" + System.Net.WebUtility.HtmlEncode(cellValue) + "</td>");
                                }
                                sw.Write("</tr>");
                            }

                            sw.Write("</table></body></html>");
                        }

                        MessageBox.Show("Đã xuất Excel thành công!", "Thông báo",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi xuất Excel: " + ex.Message, "Lỗi",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}
