using System;
using System.Drawing;
using System.Windows.Forms;

namespace Lab_14.Forms
{
    /// <summary>
    /// Form chính Lab 14 - Quản lý báo cáo Crystal Reports
    /// Giao diện trực quan, không dùng MenuBar, các nút không chứa icon, tiêu đề tinh gọn
    /// </summary>
    public partial class frmMain : Form
    {
        // Form chức năng Lab 13
        private frmBaoCaoSinhVien _frmSinhVien;
        private frmBaoCaoKhoa _frmKhoa;
        private frmBaoCaoHocPhan _frmHocPhan;

        // Form chức năng Lab 14
        private frmBaoCaoSVTheoKhoa _frmSVTheoKhoa;
        private frmBaoCaoTheoKhoangDiem _frmKhoangDiem;
        private frmBaoCaoTopSV _frmTopSV;
        private frmBaoCaoDangKyHK _frmDangKyHK;
        private frmBaoCaoBieuDo _frmBieuDo;
        private frmXuatDataGridView _frmXuatDGV;
        private frmTrungTamBaoCao _frmTrungTam;

        public frmMain()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Lab 14 - Crystal Reports - Quản lý sinh viên";
            this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Maximized;
            this.MinimumSize = new Size(950, 650);
            this.BackColor = Color.FromArgb(240, 242, 245);

            // =============================================
            // Bố cục chính tự động căn giữa toàn màn hình
            // =============================================
            TableLayoutPanel mainLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 1,
                RowCount = 3,
                BackColor = Color.Transparent
            };
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 100F)); // Khung tiêu đề gọn
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));  // Khung các nút
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 35F));  // Status bar

            // 1. Tiêu đề chính (chỉ giữ dòng chữ lớn, loại bỏ hoàn toàn các dòng chữ nhỏ)
            Label lblTitle = new Label
            {
                Text = "LAB 14 - CRYSTAL REPORTS",
                Font = new Font("Segoe UI", 26F, FontStyle.Bold),
                ForeColor = Color.FromArgb(24, 43, 73),
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter
            };
            mainLayout.Controls.Add(lblTitle, 0, 0);

            // 2. Khung chứa các nút chức năng (căn giữa)
            FlowLayoutPanel pnlButtons = new FlowLayoutPanel
            {
                Anchor = AnchorStyles.None,
                AutoSize = true,
                FlowDirection = FlowDirection.LeftToRight,
                WrapContents = true,
                MaximumSize = new Size(1100, 0),
                Padding = new Padding(10)
            };

            // Các nút Lab 14 (Không icon, không chữ nhỏ mô tả)
            Button btnBai1 = CreateButton("Báo cáo theo khoa", Color.FromArgb(30, 136, 229));
            btnBai1.Click += (s, e) => ShowForm(ref _frmSVTheoKhoa);

            Button btnBai4 = CreateButton("Báo cáo theo khoảng điểm", Color.FromArgb(21, 101, 192));
            btnBai4.Click += (s, e) => ShowForm(ref _frmKhoangDiem);

            Button btnBai6 = CreateButton("Báo cáo Top sinh viên", Color.FromArgb(46, 125, 50));
            btnBai6.Click += (s, e) => ShowForm(ref _frmTopSV);

            Button btnBai7 = CreateButton("Báo cáo đăng ký học kỳ", Color.FromArgb(56, 142, 60));
            btnBai7.Click += (s, e) => ShowForm(ref _frmDangKyHK);

            Button btnBai8 = CreateButton("Báo cáo có biểu đồ", Color.FromArgb(230, 81, 0));
            btnBai8.Click += (s, e) => ShowForm(ref _frmBieuDo);

            Button btnBai9 = CreateButton("Xuất DataGridView sang Excel", Color.FromArgb(109, 76, 65));
            btnBai9.Click += (s, e) => ShowForm(ref _frmXuatDGV);

            Button btnBai10 = CreateButton("Trung tâm báo cáo", Color.FromArgb(69, 90, 100));
            btnBai10.Click += (s, e) => ShowForm(ref _frmTrungTam);

            // Các nút báo cáo cơ bản Lab 13
            Button btnSinhVien = CreateButton("Báo cáo danh sách sinh viên", Color.FromArgb(2, 136, 209));
            btnSinhVien.Click += (s, e) => ShowForm(ref _frmSinhVien);

            Button btnKhoa = CreateButton("Báo cáo danh sách khoa", Color.FromArgb(0, 121, 107));
            btnKhoa.Click += (s, e) => ShowForm(ref _frmKhoa);

            Button btnHocPhan = CreateButton("Báo cáo danh sách học phần", Color.FromArgb(123, 31, 162));
            btnHocPhan.Click += (s, e) => ShowForm(ref _frmHocPhan);

            Button btnThoat = CreateButton("Thoát", Color.FromArgb(198, 40, 40));
            btnThoat.Click += (s, e) => Application.Exit();

            pnlButtons.Controls.AddRange(new Control[]
            {
                btnBai1, btnBai4, btnBai6, btnBai7,
                btnBai8, btnBai9, btnBai10, btnSinhVien,
                btnKhoa, btnHocPhan, btnThoat
            });

            mainLayout.Controls.Add(pnlButtons, 0, 1);

            // 3. Status Bar tinh giản
            StatusStrip statusStrip = new StatusStrip
            {
                BackColor = Color.White,
                Font = new Font("Segoe UI", 9F)
            };
            ToolStripStatusLabel lblStatus = new ToolStripStatusLabel
            {
                Text = "Hệ thống báo cáo Crystal Reports - Lab 14 | Ngày: " + DateTime.Now.ToString("dd/MM/yyyy"),
                ForeColor = Color.DimGray
            };
            statusStrip.Items.Add(lblStatus);
            mainLayout.Controls.Add(statusStrip, 0, 2);

            this.Controls.Add(mainLayout);
        }

        private Button CreateButton(string text, Color backColor)
        {
            Button btn = new Button
            {
                Text = text,
                Size = new Size(240, 65),
                Margin = new Padding(12),
                BackColor = backColor,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11F, FontStyle.Bold),
                Cursor = Cursors.Hand,
                TextAlign = ContentAlignment.MiddleCenter
            };
            btn.FlatAppearance.BorderSize = 0;
            return btn;
        }

        private void ShowForm<T>(ref T formField) where T : Form, new()
        {
            if (formField == null || formField.IsDisposed)
            {
                formField = new T();
                T f = formField;
                formField.FormClosed += delegate { f = null; };
                formField.Show();
            }
            else
            {
                formField.BringToFront();
                formField.Focus();
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có chắc chắn muốn thoát ứng dụng?", "Xác nhận",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.No)
            {
                e.Cancel = true;
                return;
            }

            CloseForm(_frmSinhVien);
            CloseForm(_frmKhoa);
            CloseForm(_frmHocPhan);
            CloseForm(_frmSVTheoKhoa);
            CloseForm(_frmKhoangDiem);
            CloseForm(_frmTopSV);
            CloseForm(_frmDangKyHK);
            CloseForm(_frmBieuDo);
            CloseForm(_frmXuatDGV);
            CloseForm(_frmTrungTam);

            base.OnFormClosing(e);
        }

        private void CloseForm(Form frm)
        {
            if (frm != null && !frm.IsDisposed) frm.Close();
        }
    }
}
