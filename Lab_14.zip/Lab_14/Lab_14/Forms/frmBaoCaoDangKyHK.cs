using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Lab_14;
using Lab_14.Reports;
using Lab_14.DAL;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using CrystalDecisions.Windows.Forms;

namespace Lab_14.Forms
{
    /// <summary>
    /// Bài 7: Báo cáo đăng ký theo học kỳ qua Crystal Reports
    /// Nhóm theo học kỳ và học phần; thống kê số lượt đăng ký, điểm trung bình
    /// </summary>
    public partial class frmBaoCaoDangKyHK : Form
    {
        private ReportDocument _report;
        private CrystalReportViewer crystalReportViewer1;
        private Button btnXemBaoCao;
        private Button btnXuatPdf;
        private Button btnXuatExcel;
        private Button btnClose;
        private BaoCaoDAL _dal = new BaoCaoDAL();

        public frmBaoCaoDangKyHK()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Báo cáo đăng ký học phần theo học kỳ";
            this.Size = new Size(1100, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Maximized;

            // === Panel Bottom ===
            Panel pnlButtons = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                Padding = new Padding(10)
            };

            btnXemBaoCao = new Button
            {
                Text = "Xem báo cáo",
                Size = new Size(130, 35),
                Location = new Point(10, 8),
                BackColor = Color.FromArgb(30, 136, 229),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnXemBaoCao.Click += delegate { LoadReport(); };

            btnXuatPdf = new Button
            {
                Text = "Xuất PDF",
                Size = new Size(120, 35),
                Location = new Point(150, 8),
                BackColor = Color.SteelBlue,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnXuatPdf.Click += btnXuatPdf_Click;

            btnXuatExcel = new Button
            {
                Text = "Xuất Excel",
                Size = new Size(120, 35),
                Location = new Point(280, 8),
                BackColor = Color.FromArgb(46, 125, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnXuatExcel.Click += btnXuatExcel_Click;

            btnClose = new Button
            {
                Text = "Đóng",
                Size = new Size(120, 35),
                Location = new Point(410, 8),
                BackColor = Color.Gray,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnClose.Click += delegate { this.Close(); };

            pnlButtons.Controls.AddRange(new Control[] { btnXemBaoCao, btnXuatPdf, btnXuatExcel, btnClose });

            // === CrystalReportViewer ===
            crystalReportViewer1 = new CrystalReportViewer
            {
                Dock = DockStyle.Fill,
                ShowGroupTreeButton = true,
                ToolPanelView = ToolPanelViewType.None
            };

            this.Controls.Add(crystalReportViewer1);
            this.Controls.Add(pnlButtons);

            this.Load += (s, e) => LoadReport();
        }

        private void LoadReport()
        {
            try
            {
                DataTable data = _dal.GetDangKyTheoHocKy();

                if (_report != null)
                {
                    _report.Close();
                    _report.Dispose();
                    _report = null;
                }

                try
                {
                    _report = new rptDangKyHocKy();
                }
                catch { }

                if (_report == null || _report.Database.Tables.Count == 0)
                {
                    string[] searchPaths = new string[]
                    {
                        Path.Combine(Application.StartupPath, @"Reports\rptDangKyHocKy.rpt"),
                        Path.Combine(Application.StartupPath, "rptDangKyHocKy.rpt"),
                        Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\Reports\rptDangKyHocKy.rpt")
                    };

                    foreach (string path in searchPaths)
                    {
                        if (File.Exists(path))
                        {
                            try
                            {
                                ReportDocument doc = new ReportDocument();
                                doc.Load(path);
                                if (doc.Database.Tables.Count > 0)
                                {
                                    if (_report != null) { _report.Close(); _report.Dispose(); }
                                    _report = doc;
                                    break;
                                }
                                else if (_report == null)
                                {
                                    _report = doc;
                                }
                                else
                                {
                                    doc.Close();
                                    doc.Dispose();
                                }
                            }
                            catch { }
                        }
                    }
                }

                if (_report == null || _report.Database.Tables.Count == 0)
                {
                    MessageBox.Show(
                        "Báo cáo 'rptDangKyHocKy.rpt' chưa có bảng dữ liệu (0 tables).\n\n" +
                        "Hướng dẫn gắn bảng trong Visual Studio:\n" +
                        "1. Mở file rptDangKyHocKy.rpt trong Visual Studio\n" +
                        "2. Nhấp chuột phải -> Database -> Database Expert...\n" +
                        "3. Thêm bảng/view (vw_BaoCaoDangKyHocKy) vào mục 'Selected Tables' -> bấm OK\n" +
                        "4. Kéo các trường vào báo cáo và nhấn Ctrl + S để lưu lại.",
                        "Thông báo cấu hình báo cáo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string rptTable = _report.Database.Tables[0].Name;
                if (!string.IsNullOrEmpty(rptTable) && data.TableName != rptTable)
                {
                    data.TableName = rptTable;
                }

                _report.SetDataSource(data);

                try
                {
                    _report.SetParameterValue("pTenKhoa", "Báo cáo đăng ký học phần theo học kỳ");
                }
                catch { }

                try
                {
                    _report.SetParameterValue("pNgayLap", DateTime.Now);
                }
                catch { }

                // Làm sạch bố cục: chỉ hiển thị bảng danh sách chuẩn như rptSinhVien / rptKhoa, ẩn biểu đồ chèn thừa
                ReportHelper.CleanTabularLayout(_report);

                crystalReportViewer1.ReportSource = _report;
                crystalReportViewer1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải báo cáo: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXuatPdf_Click(object sender, EventArgs e)
        {
            if (_report == null)
            {
                MessageBox.Show("Chưa có báo cáo để xuất. Hãy bấm Xem báo cáo trước.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Filter = "PDF file|*.pdf";
                dlg.FileName = "BaoCaoDangKyHocKy.pdf";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    _report.ExportToDisk(ExportFormatType.PortableDocFormat, dlg.FileName);
                    MessageBox.Show("Đã xuất PDF thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnXuatExcel_Click(object sender, EventArgs e)
        {
            if (_report == null)
            {
                MessageBox.Show("Chưa có báo cáo để xuất. Hãy bấm Xem báo cáo trước.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Filter = "Excel Workbook|*.xls";
                dlg.FileName = "BaoCaoDangKyHocKy.xls";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    _report.ExportToDisk(ExportFormatType.ExcelWorkbook, dlg.FileName);
                    MessageBox.Show("Đã xuất Excel thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            if (_report != null)
            {
                _report.Close();
                _report.Dispose();
                _report = null;
            }
            base.OnFormClosed(e);
        }
    }
}
