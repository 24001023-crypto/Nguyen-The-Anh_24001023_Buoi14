using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Lab_14;
using Lab_14.Reports;
using Lab_14.DAL;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using CrystalDecisions.Windows.Forms;

namespace Lab_14.Forms
{
    /// <summary>
    /// Báo cáo danh sách khoa qua Crystal Reports
    /// </summary>
    public partial class frmBaoCaoKhoa : Form
    {
        private ReportDocument _report;
        private CrystalReportViewer crystalReportViewer1;
        private Button btnXuatPdf;
        private Button btnXuatExcel;
        private Button btnRefresh;
        private Button btnClose;

        public frmBaoCaoKhoa()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Báo cáo danh sách khoa";
            this.Size = new Size(1000, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Maximized;

            Panel pnlButtons = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                Padding = new Padding(10)
            };

            btnXuatPdf = new Button
            {
                Text = "Xuất PDF",
                Size = new Size(120, 35),
                Location = new Point(10, 8),
                BackColor = Color.SteelBlue,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnXuatPdf.Click += btnXuatPdf_Click;

            btnXuatExcel = new Button
            {
                Text = "Xuất Excel",
                Size = new Size(120, 35),
                Location = new Point(140, 8),
                BackColor = Color.FromArgb(46, 125, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnXuatExcel.Click += btnXuatExcel_Click;

            btnRefresh = new Button
            {
                Text = "Làm mới",
                Size = new Size(120, 35),
                Location = new Point(270, 8),
                BackColor = Color.SeaGreen,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnRefresh.Click += delegate { LoadReport(); };

            btnClose = new Button
            {
                Text = "Đóng",
                Size = new Size(120, 35),
                Location = new Point(400, 8),
                BackColor = Color.Gray,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnClose.Click += delegate { this.Close(); };

            pnlButtons.Controls.AddRange(new Control[] { btnXuatPdf, btnXuatExcel, btnRefresh, btnClose });

            crystalReportViewer1 = new CrystalReportViewer
            {
                Dock = DockStyle.Fill,
                ShowGroupTreeButton = false,
                ToolPanelView = ToolPanelViewType.None
            };

            this.Controls.Add(crystalReportViewer1);
            this.Controls.Add(pnlButtons);
            this.Load += frmBaoCaoKhoa_Load;
        }

        private void frmBaoCaoKhoa_Load(object sender, EventArgs e)
        {
            LoadReport();
        }

        private void LoadReport()
        {
            try
            {
                DataTable data = new BaoCaoDAL().GetKhoaReportData();

                if (_report != null)
                {
                    _report.Close();
                    _report.Dispose();
                    _report = null;
                }

                try
                {
                    _report = new rptKhoa();
                }
                catch { }

                if (_report == null || _report.Database.Tables.Count == 0)
                {
                    string[] searchPaths = new string[]
                    {
                        Path.Combine(Application.StartupPath, @"Reports\rptKhoa.rpt"),
                        Path.Combine(Application.StartupPath, "rptKhoa.rpt"),
                        Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\Reports\rptKhoa.rpt")
                    };

                    foreach (string path in searchPaths)
                    {
                        if (File.Exists(path))
                        {
                            try
                            {
                                ReportDocument doc = new ReportDocument();
                                doc.Load(path);
                                if (doc.Database.Tables.Count > 0)
                                {
                                    if (_report != null) { _report.Close(); _report.Dispose(); }
                                    _report = doc;
                                    break;
                                }
                                else if (_report == null)
                                {
                                    _report = doc;
                                }
                                else
                                {
                                    doc.Close();
                                    doc.Dispose();
                                }
                            }
                            catch { }
                        }
                    }
                }

                if (_report == null || _report.Database.Tables.Count == 0)
                {
                    MessageBox.Show(
                        "Báo cáo 'rptKhoa.rpt' chưa có bảng dữ liệu (0 tables).\n\n" +
                        "Hướng dẫn gắn bảng trong Visual Studio:\n" +
                        "1. Mở file rptKhoa.rpt trong Visual Studio\n" +
                        "2. Nhấp chuột phải -> Database -> Database Expert...\n" +
                        "3. Thêm bảng hoặc view (vw_BaoCaoKhoa) vào mục 'Selected Tables' -> bấm OK\n" +
                        "4. Kéo các trường vào báo cáo và nhấn Ctrl + S để lưu lại.",
                        "Thông báo cấu hình báo cáo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string rptTable = _report.Database.Tables[0].Name;
                if (!string.IsNullOrEmpty(rptTable) && data.TableName != rptTable)
                {
                    data.TableName = rptTable;
                }

                _report.SetDataSource(data);
                crystalReportViewer1.ReportSource = _report;
                crystalReportViewer1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải báo cáo: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXuatPdf_Click(object sender, EventArgs e)
        {
            if (_report == null)
            {
                MessageBox.Show("Chưa có báo cáo để xuất.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Filter = "PDF file|*.pdf";
                dlg.FileName = "DanhSachKhoa.pdf";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    _report.ExportToDisk(ExportFormatType.PortableDocFormat, dlg.FileName);
                    MessageBox.Show("Đã xuất báo cáo thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnXuatExcel_Click(object sender, EventArgs e)
        {
            if (_report == null)
            {
                MessageBox.Show("Chưa có báo cáo để xuất.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Filter = "Excel Workbook|*.xls";
                dlg.FileName = "DanhSachKhoa.xls";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    _report.ExportToDisk(ExportFormatType.ExcelWorkbook, dlg.FileName);
                    MessageBox.Show("Đã xuất Excel thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            if (_report != null)
            {
                _report.Close();
                _report.Dispose();
                _report = null;
            }
            base.OnFormClosed(e);
        }
    }
}
