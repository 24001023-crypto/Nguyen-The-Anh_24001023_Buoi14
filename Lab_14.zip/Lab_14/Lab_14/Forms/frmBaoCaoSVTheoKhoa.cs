using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Lab_14;
using Lab_14.Reports;
using Lab_14.DAL;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using CrystalDecisions.Windows.Forms;

namespace Lab_14.Forms
{
    /// <summary>
    /// Bài 1, 2, 3, 5: Báo cáo sinh viên theo khoa qua Crystal Reports
    /// Khớp code mẫu: ReportDocument report = new CrystalReportSinhVienTheoKhoa();
    /// Lọc theo khoa, truyền Parameter (pTenKhoa, pNgayLap), Group TenKhoa, Thống kê, Xếp loại, Xuất Excel
    /// </summary>
    public partial class frmBaoCaoSVTheoKhoa : Form
    {
        private ReportDocument _report;
        private CrystalReportViewer crystalReportViewer1;
        private ComboBox cboKhoa;
        private Button btnXemBaoCao;
        private Button btnXuatPdf;
        private Button btnXuatExcel;
        private Button btnClose;
        private BaoCaoDAL _dal = new BaoCaoDAL();

        public frmBaoCaoSVTheoKhoa()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Báo cáo sinh viên theo khoa";
            this.Size = new Size(1100, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Maximized;

            // === Panel Top ===
            Panel pnlTop = new Panel
            {
                Dock = DockStyle.Top,
                Height = 60,
                Padding = new Padding(10),
                BackColor = Color.FromArgb(240, 244, 248)
            };

            Label lblKhoa = new Label
            {
                Text = "Chọn khoa:",
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                Location = new Point(15, 18),
                AutoSize = true
            };

            cboKhoa = new ComboBox
            {
                Location = new Point(110, 15),
                Size = new Size(300, 30),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10F)
            };
            cboKhoa.SelectedIndexChanged += (s, e) =>
            {
                if (cboKhoa.SelectedValue != null)
                {
                    btnXemBaoCao_Click(null, null);
                }
            };

            btnXemBaoCao = new Button
            {
                Text = "Xem báo cáo",
                Size = new Size(130, 35),
                Location = new Point(430, 12),
                BackColor = Color.FromArgb(30, 136, 229),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnXemBaoCao.Click += btnXemBaoCao_Click;

            pnlTop.Controls.AddRange(new Control[] { lblKhoa, cboKhoa, btnXemBaoCao });

            // === Panel Bottom ===
            Panel pnlButtons = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                Padding = new Padding(10)
            };

            btnXuatPdf = new Button
            {
                Text = "Xuất PDF",
                Size = new Size(120, 35),
                Location = new Point(10, 8),
                BackColor = Color.SteelBlue,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnXuatPdf.Click += btnXuatPdf_Click;

            btnXuatExcel = new Button
            {
                Text = "Xuất Excel",
                Size = new Size(120, 35),
                Location = new Point(140, 8),
                BackColor = Color.FromArgb(46, 125, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnXuatExcel.Click += btnXuatExcel_Click;

            btnClose = new Button
            {
                Text = "Đóng",
                Size = new Size(120, 35),
                Location = new Point(270, 8),
                BackColor = Color.Gray,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnClose.Click += delegate { this.Close(); };

            pnlButtons.Controls.AddRange(new Control[] { btnXuatPdf, btnXuatExcel, btnClose });

            // === CrystalReportViewer ===
            crystalReportViewer1 = new CrystalReportViewer
            {
                Dock = DockStyle.Fill,
                ShowGroupTreeButton = true,
                ToolPanelView = ToolPanelViewType.None
            };

            this.Controls.Add(crystalReportViewer1);
            this.Controls.Add(pnlTop);
            this.Controls.Add(pnlButtons);

            this.Load += frmBaoCaoSVTheoKhoa_Load;
        }

        private void frmBaoCaoSVTheoKhoa_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable dtKhoa = _dal.GetDanhSachKhoa();
                DataRow drAll = dtKhoa.NewRow();
                drAll["MaKhoa"] = "ALL";
                drAll["TenKhoa"] = "-- Tất cả các khoa --";
                dtKhoa.Rows.InsertAt(drAll, 0);

                cboKhoa.DataSource = dtKhoa;
                cboKhoa.DisplayMember = "TenKhoa";
                cboKhoa.ValueMember = "MaKhoa";

                if (dtKhoa.Rows.Count > 1)
                    cboKhoa.SelectedIndex = 1;
                else
                    cboKhoa.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh sách khoa: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXemBaoCao_Click(object sender, EventArgs e)
        {
            try
            {
                string maKhoa = cboKhoa.SelectedValue?.ToString();
                string tenKhoa = cboKhoa.Text;

                DataTable data;
                if (string.IsNullOrEmpty(maKhoa) || maKhoa == "ALL")
                {
                    data = _dal.GetStudentReportData();
                    tenKhoa = "Tất cả các khoa";
                }
                else
                {
                    data = _dal.GetStudentsByDepartment(maKhoa);
                }

                if (_report != null)
                {
                    _report.Close();
                    _report.Dispose();
                    _report = null;
                }

                try
                {
                    _report = new CrystalReportSinhVienTheoKhoa();
                }
                catch
                {
                    try
                    {
                        _report = new rptSinhVien();
                    }
                    catch { }
                }

                if (_report == null || _report.Database.Tables.Count == 0)
                {
                    string[] searchPaths = new string[]
                    {
                        Path.Combine(Application.StartupPath, @"Reports\CrystalReportSinhVienTheoKhoa.rpt"),
                        Path.Combine(Application.StartupPath, "CrystalReportSinhVienTheoKhoa.rpt"),
                        Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\Reports\CrystalReportSinhVienTheoKhoa.rpt"),
                        Path.Combine(Application.StartupPath, @"Reports\rptSinhVien.rpt"),
                        Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\Reports\rptSinhVien.rpt")
                    };

                    foreach (string path in searchPaths)
                    {
                        if (File.Exists(path))
                        {
                            try
                            {
                                ReportDocument doc = new ReportDocument();
                                doc.Load(path);
                                if (doc.Database.Tables.Count > 0)
                                {
                                    if (_report != null) { _report.Close(); _report.Dispose(); }
                                    _report = doc;
                                    break;
                                }
                                else if (_report == null)
                                {
                                    _report = doc;
                                }
                                else
                                {
                                    doc.Close();
                                    doc.Dispose();
                                }
                            }
                            catch { }
                        }
                    }
                }

                if (_report == null || _report.Database.Tables.Count == 0)
                {
                    MessageBox.Show(
                        "Báo cáo 'CrystalReportSinhVienTheoKhoa.rpt' chưa có bảng dữ liệu (0 tables).\n\n" +
                        "Hướng dẫn gắn bảng trong Visual Studio:\n" +
                        "1. Mở file CrystalReportSinhVienTheoKhoa.rpt trong Visual Studio\n" +
                        "2. Nhấp chuột phải -> Database -> Database Expert...\n" +
                        "3. Thêm bảng/view (vw_BaoCaoSinhVien) vào mục 'Selected Tables' -> bấm OK\n" +
                        "4. Kéo các trường vào báo cáo và nhấn Ctrl + S để lưu lại.",
                        "Thông báo cấu hình báo cáo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string rptTable = _report.Database.Tables[0].Name;
                if (!string.IsNullOrEmpty(rptTable) && data.TableName != rptTable)
                {
                    data.TableName = rptTable;
                }

                _report.SetDataSource(data);

                try
                {
                    _report.SetParameterValue("pTenKhoa", tenKhoa);
                }
                catch { }

                try
                {
                    _report.SetParameterValue("pNgayLap", DateTime.Now);
                }
                catch { }

                // Làm sạch bố cục: chỉ hiển thị bảng danh sách chuẩn như rptSinhVien / rptKhoa, ẩn biểu đồ chèn thừa
                ReportHelper.CleanTabularLayout(_report);

                crystalReportViewer1.ReportSource = _report;
                crystalReportViewer1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải báo cáo: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnXuatPdf_Click(object sender, EventArgs e)
        {
            if (_report == null)
            {
                MessageBox.Show("Chưa có báo cáo để xuất. Hãy bấm Xem báo cáo trước.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Filter = "PDF file|*.pdf";
                dlg.FileName = "BaoCaoSVTheoKhoa.pdf";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    _report.ExportToDisk(ExportFormatType.PortableDocFormat, dlg.FileName);
                    MessageBox.Show("Đã xuất PDF thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnXuatExcel_Click(object sender, EventArgs e)
        {
            if (_report == null)
            {
                MessageBox.Show("Chưa có báo cáo để xuất. Hãy bấm Xem báo cáo trước.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Filter = "Excel Workbook|*.xls";
                dlg.FileName = "BaoCaoSVTheoKhoa.xls";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    _report.ExportToDisk(ExportFormatType.ExcelWorkbook, dlg.FileName);
                    MessageBox.Show("Đã xuất Excel thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            if (_report != null)
            {
                _report.Close();
                _report.Dispose();
                _report = null;
            }
            base.OnFormClosed(e);
        }
    }
}
