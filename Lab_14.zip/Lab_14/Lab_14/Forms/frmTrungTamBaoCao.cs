using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using Lab_14;
using Lab_14.Reports;
using Lab_14.DAL;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using CrystalDecisions.Windows.Forms;

namespace Lab_14.Forms
{
    /// <summary>
    /// Bài 10: Trung tâm báo cáo qua Crystal Reports
    /// Form cho phép chọn loại báo cáo, tham số, xem trước trên CrystalReportViewer và xuất PDF/Excel
    /// </summary>
    public partial class frmTrungTamBaoCao : Form
    {
        private ReportDocument _report;
        private CrystalReportViewer crystalReportViewer1;
        private ComboBox cboLoaiBaoCao;
        private ComboBox cboKhoa;
        private Panel pnlThamSo;
        private Label lblThamSo;
        private Button btnXemTruoc;
        private Button btnXuatPdf;
        private Button btnXuatExcel;
        private Button btnClose;
        private BaoCaoDAL _dal = new BaoCaoDAL();

        public frmTrungTamBaoCao()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Trung tâm báo cáo";
            this.Size = new Size(1200, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.WindowState = FormWindowState.Maximized;

            // === Panel Top: Chọn loại báo cáo & tham số ===
            Panel pnlTop = new Panel
            {
                Dock = DockStyle.Top,
                Height = 100,
                BackColor = Color.FromArgb(240, 244, 248),
                Padding = new Padding(12)
            };

            // Dòng 1: Chọn loại báo cáo
            Label lblLoai = new Label
            {
                Text = "Loại báo cáo:",
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                Location = new Point(15, 15),
                AutoSize = true
            };

            cboLoaiBaoCao = new ComboBox
            {
                Location = new Point(130, 12),
                Size = new Size(340, 30),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10F)
            };
            cboLoaiBaoCao.Items.AddRange(new object[]
            {
                "Danh sách sinh viên",
                "Danh sách khoa",
                "Danh sách học phần",
                "Sinh viên theo khoa",
                "Sinh viên theo khoảng điểm",
                "Đăng ký theo học kỳ",
                "Báo cáo có biểu đồ"
            });
            cboLoaiBaoCao.SelectedIndex = 0;
            cboLoaiBaoCao.SelectedIndexChanged += cboLoaiBaoCao_SelectedIndexChanged;

            btnXemTruoc = new Button
            {
                Text = "Xem trước",
                Size = new Size(120, 35),
                Location = new Point(490, 10),
                BackColor = Color.FromArgb(30, 136, 229),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnXemTruoc.Click += btnXemTruoc_Click;

            // Dòng 2: Tham số (khoa)
            pnlThamSo = new Panel
            {
                Location = new Point(0, 50),
                Size = new Size(650, 45),
                BackColor = Color.Transparent
            };

            lblThamSo = new Label
            {
                Text = "Khoa:",
                Font = new Font("Segoe UI", 10F, FontStyle.Bold),
                Location = new Point(15, 12),
                AutoSize = true
            };

            cboKhoa = new ComboBox
            {
                Location = new Point(130, 9),
                Size = new Size(340, 30),
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10F)
            };

            pnlThamSo.Controls.AddRange(new Control[] { lblThamSo, cboKhoa });
            pnlThamSo.Visible = false;

            pnlTop.Controls.AddRange(new Control[] { lblLoai, cboLoaiBaoCao, btnXemTruoc, pnlThamSo });

            // === Panel Bottom: Xuất ===
            Panel pnlButtons = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                Padding = new Padding(10)
            };

            btnXuatPdf = new Button
            {
                Text = "Xuất PDF",
                Size = new Size(120, 35),
                Location = new Point(10, 8),
                BackColor = Color.SteelBlue,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnXuatPdf.Click += btnXuatPdf_Click;

            btnXuatExcel = new Button
            {
                Text = "Xuất Excel",
                Size = new Size(120, 35),
                Location = new Point(140, 8),
                BackColor = Color.FromArgb(46, 125, 50),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnXuatExcel.Click += btnXuatExcel_Click;

            btnClose = new Button
            {
                Text = "Đóng",
                Size = new Size(120, 35),
                Location = new Point(270, 8),
                BackColor = Color.Gray,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5F, FontStyle.Bold)
            };
            btnClose.Click += delegate { this.Close(); };

            pnlButtons.Controls.AddRange(new Control[] { btnXuatPdf, btnXuatExcel, btnClose });

            // === CrystalReportViewer ===
            crystalReportViewer1 = new CrystalReportViewer
            {
                Dock = DockStyle.Fill,
                ShowGroupTreeButton = true,
                ToolPanelView = ToolPanelViewType.None
            };

            this.Controls.Add(crystalReportViewer1);
            this.Controls.Add(pnlTop);
            this.Controls.Add(pnlButtons);

            this.Load += frmTrungTamBaoCao_Load;
        }

        private void frmTrungTamBaoCao_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable dtKhoa = _dal.GetDanhSachKhoa();
                DataRow drAll = dtKhoa.NewRow();
                drAll["MaKhoa"] = "ALL";
                drAll["TenKhoa"] = "-- Tất cả các khoa --";
                dtKhoa.Rows.InsertAt(drAll, 0);
                cboKhoa.DataSource = dtKhoa;
                cboKhoa.DisplayMember = "TenKhoa";
                cboKhoa.ValueMember = "MaKhoa";
            }
            catch { }

            // Tự động xem trước báo cáo đầu tiên
            btnXemTruoc_Click(null, null);
        }

        private void cboLoaiBaoCao_SelectedIndexChanged(object sender, EventArgs e)
        {
            int idx = cboLoaiBaoCao.SelectedIndex;
            pnlThamSo.Visible = (idx == 3);
            btnXemTruoc_Click(null, null);
        }

        private void btnXemTruoc_Click(object sender, EventArgs e)
        {
            try
            {
                int idx = cboLoaiBaoCao.SelectedIndex;
                DataTable data = null;
                string rptName = "";
                string paramTitle = "";

                switch (idx)
                {
                    case 0: // Danh sách sinh viên
                        data = _dal.GetStudentReportData();
                        rptName = "rptSinhVien";
                        paramTitle = "Danh sách sinh viên";
                        break;
                    case 1: // Danh sách khoa
                        data = _dal.GetKhoaReportData();
                        rptName = "rptKhoa";
                        break;
                    case 2: // Danh sách học phần
                        data = _dal.GetHocPhanReportData();
                        rptName = "rptHocPhan";
                        break;
                    case 3: // Sinh viên theo khoa
                        string maKhoa = cboKhoa.SelectedValue?.ToString();
                        if (string.IsNullOrEmpty(maKhoa) || maKhoa == "ALL")
                        {
                            data = _dal.GetStudentReportData();
                            paramTitle = "Tất cả các khoa";
                        }
                        else
                        {
                            data = _dal.GetStudentsByDepartment(maKhoa);
                            paramTitle = cboKhoa.Text;
                        }
                        rptName = "rptSinhVien";
                        break;
                    case 4: // Sinh viên theo khoảng điểm
                        data = _dal.GetStudentReportData();
                        rptName = "rptSinhVien";
                        paramTitle = "Danh sách sinh viên theo điểm";
                        break;
                    case 5: // Đăng ký theo học kỳ
                        data = _dal.GetDangKyTheoHocKy();
                        rptName = "rptDangKyHocKy";
                        break;
                    case 6: // Báo cáo có biểu đồ
                        data = _dal.GetStudentReportData();
                        rptName = "rptBieuDo";
                        break;
                }

                if (data == null) return;

                if (_report != null)
                {
                    _report.Close();
                    _report.Dispose();
                    _report = null;
                }

                switch (rptName)
                {
                    case "rptSinhVien":
                        try { _report = new rptSinhVien(); } catch { }
                        break;
                    case "rptKhoa":
                        try { _report = new rptKhoa(); } catch { }
                        break;
                    case "rptHocPhan":
                        try { _report = new rptHocPhan(); } catch { }
                        break;
                    case "rptDangKyHocKy":
                        try { _report = new rptDangKyHocKy(); } catch { }
                        break;
                    case "rptBieuDo":
                        try { _report = new rptBieuDo(); } catch { }
                        break;
                }

                if (_report == null || _report.Database.Tables.Count == 0)
                {
                    LoadReportFromFile(rptName);
                }

                if (_report == null || _report.Database.Tables.Count == 0)
                {
                    MessageBox.Show(
                        "Báo cáo '" + rptName + ".rpt' chưa có bảng dữ liệu (0 tables).\n\n" +
                        "Hướng dẫn gắn bảng trong Visual Studio:\n" +
                        "1. Mở file " + rptName + ".rpt trong Visual Studio\n" +
                        "2. Nhấp chuột phải -> Database -> Database Expert...\n" +
                        "3. Thêm bảng hoặc view tương ứng vào mục 'Selected Tables' -> bấm OK\n" +
                        "4. Kéo các trường vào báo cáo và nhấn Ctrl + S để lưu lại.",
                        "Thông báo cấu hình báo cáo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string rptTable = _report.Database.Tables[0].Name;
                if (!string.IsNullOrEmpty(rptTable) && data.TableName != rptTable)
                {
                    data.TableName = rptTable;
                }

                _report.SetDataSource(data);

                if (!string.IsNullOrEmpty(paramTitle))
                {
                    try { _report.SetParameterValue("pTenKhoa", paramTitle); } catch { }
                    try { _report.SetParameterValue("pNgayLap", DateTime.Now); } catch { }
                }

                if (rptName == "rptBieuDo")
                {
                    // Với báo cáo biểu đồ: ẩn bảng chi tiết 20 dòng ở dưới để biểu đồ hiển thị to rõ, không rối mắt
                    ReportHelper.OptimizeChartLayout(_report, true);
                }
                else
                {
                    // Với các báo cáo danh sách: ẩn biểu đồ để chỉ hiển thị bảng dữ liệu sạch sẽ chuẩn như rptSinhVien / rptKhoa
                    ReportHelper.CleanTabularLayout(_report);
                }

                crystalReportViewer1.ReportSource = _report;
                crystalReportViewer1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải báo cáo: " + ex.Message, "Lỗi",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadReportFromFile(string rptName)
        {
            string[] searchPaths = new string[]
            {
                Path.Combine(Application.StartupPath, @"Reports\" + rptName + ".rpt"),
                Path.Combine(Application.StartupPath, rptName + ".rpt"),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\Reports\" + rptName + ".rpt"),
                Path.Combine(Application.StartupPath, @"Reports\rptSinhVien.rpt"),
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\Reports\rptSinhVien.rpt")
            };

            foreach (string path in searchPaths)
            {
                if (File.Exists(path))
                {
                    try
                    {
                        ReportDocument doc = new ReportDocument();
                        doc.Load(path);
                        if (doc.Database.Tables.Count > 0)
                        {
                            if (_report != null) { _report.Close(); _report.Dispose(); }
                            _report = doc;
                            return;
                        }
                        else if (_report == null)
                        {
                            _report = doc;
                        }
                        else
                        {
                            doc.Close();
                            doc.Dispose();
                        }
                    }
                    catch { }
                }
            }
        }

        private void btnXuatPdf_Click(object sender, EventArgs e)
        {
            if (_report == null)
            {
                MessageBox.Show("Chưa có báo cáo. Hãy bấm Xem trước trước khi xuất.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Filter = "PDF file|*.pdf";
                dlg.FileName = "BaoCao.pdf";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    _report.ExportToDisk(ExportFormatType.PortableDocFormat, dlg.FileName);
                    MessageBox.Show("Đã xuất PDF thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void btnXuatExcel_Click(object sender, EventArgs e)
        {
            if (_report == null)
            {
                MessageBox.Show("Chưa có báo cáo. Hãy bấm Xem trước trước khi xuất.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SaveFileDialog dlg = new SaveFileDialog())
            {
                dlg.Filter = "Excel Workbook|*.xls";
                dlg.FileName = "BaoCao.xls";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    _report.ExportToDisk(ExportFormatType.ExcelWorkbook, dlg.FileName);
                    MessageBox.Show("Đã xuất Excel thành công!", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            if (_report != null)
            {
                _report.Close();
                _report.Dispose();
                _report = null;
            }
            base.OnFormClosed(e);
        }
    }
}
