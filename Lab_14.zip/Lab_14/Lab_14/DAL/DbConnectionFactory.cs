using System;
using System.Configuration;
using System.Data.SqlClient;

namespace Lab_14.DAL
{
    /// <summary>
    /// Factory tạo kết nối SQL Server
    /// Tự động kiểm tra và nhận diện instance SQL Server (., .\\SQLEXPRESS, localhost, (local))
    /// </summary>
    public static class DbConnectionFactory
    {
        private static string _workingConnectionString;

        private static readonly string[] CandidateServers = new[]
        {
            ".",
            @".\SQLEXPRESS",
            "localhost",
            "(local)"
        };

        public static string GetConnectionString()
        {
            if (!string.IsNullOrEmpty(_workingConnectionString))
                return _workingConnectionString;

            // 1. Thử chuỗi kết nối từ App.config
            try
            {
                ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["QLSinhVien"];
                if (settings != null && !string.IsNullOrWhiteSpace(settings.ConnectionString))
                {
                    if (TestConnection(settings.ConnectionString))
                    {
                        _workingConnectionString = settings.ConnectionString;
                        return _workingConnectionString;
                    }
                }
            }
            catch { }

            // 2. Thử lần lượt các server thông dụng: ., .\SQLEXPRESS, localhost, (local)
            foreach (string srv in CandidateServers)
            {
                string connStr = string.Format(
                    "Data Source={0};Initial Catalog=QLSinhVien;Integrated Security=True;TrustServerCertificate=True", srv);
                if (TestConnection(connStr))
                {
                    _workingConnectionString = connStr;
                    return _workingConnectionString;
                }
            }

            // Mặc định
            return "Data Source=.;Initial Catalog=QLSinhVien;Integrated Security=True;TrustServerCertificate=True";
        }

        private static bool TestConnection(string connStr)
        {
            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(connStr)
                {
                    ConnectTimeout = 2 // Timeout ngắn để test nhanh
                };
                using (SqlConnection conn = new SqlConnection(builder.ConnectionString))
                {
                    conn.Open();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Tạo một SqlConnection mới (chưa mở)
        /// </summary>
        public static SqlConnection Create()
        {
            return new SqlConnection(GetConnectionString());
        }
    }
}
