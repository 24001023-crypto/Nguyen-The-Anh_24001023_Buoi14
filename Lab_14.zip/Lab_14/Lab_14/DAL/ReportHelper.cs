using System;
using CrystalDecisions.CrystalReports.Engine;

namespace Lab_14
{
    /// <summary>
    /// Tiện ích định dạng và tối ưu giao diện báo cáo Crystal Reports:
    /// - Loại bỏ biểu đồ chèn thừa ở các báo cáo danh sách để chỉ hiển thị bảng biểu gọn gàng, rõ ràng (như rptSinhVien / rptKhoa).
    /// - Cho phép ẩn/hiện bảng chi tiết dưới biểu đồ ở báo cáo Bài 8 để tránh bị rối mắt.
    /// </summary>
    public static class ReportHelper
    {
        /// <summary>
        /// Chuẩn hóa báo cáo thành dạng bảng thuần túy (Tabular Report):
        /// Tự động ẩn mọi ChartObject và ẩn luôn Section chứa biểu đồ để trang báo cáo chỉ hiển thị
        /// bảng dữ liệu danh sách sạch sẽ, các cột thẳng hàng, không bị biểu đồ làm vỡ bố cục.
        /// </summary>
        public static void CleanTabularLayout(ReportDocument report)
        {
            if (report == null) return;
            try
            {
                foreach (Section sec in report.ReportDefinition.Sections)
                {
                    bool hasChart = false;
                    foreach (ReportObject obj in sec.ReportObjects)
                    {
                        if (obj is ChartObject)
                        {
                            hasChart = true;
                            obj.ObjectFormat.EnableSuppress = true;
                        }
                    }
                    if (hasChart)
                    {
                        sec.SectionFormat.EnableSuppress = true;
                    }
                }
            }
            catch { }
        }

        /// <summary>
        /// Tối ưu giao diện cho Báo cáo có biểu đồ (Bài 8):
        /// Ẩn bảng danh sách chi tiết (Details section) bên dưới biểu đồ để biểu đồ hiển thị to, rõ ràng,
        /// không bị 20 hàng sinh viên liệt kê ở dưới làm rối mắt.
        /// </summary>
        public static void OptimizeChartLayout(ReportDocument report, bool hideDetailsTable = true)
        {
            if (report == null) return;
            try
            {
                // Trong Crystal Reports chuẩn:
                // Section 1: Report Header (Chứa Title & Chart)
                // Section 2: Page Header
                // Section 3: Details (Bảng liệt kê từng dòng dữ liệu)
                // Section 4: Report Footer
                // Section 5: Page Footer
                foreach (Section sec in report.ReportDefinition.Sections)
                {
                    // Section chi tiết thường có tên "Section3" hoặc chứa từ khóa "Detail"
                    if (sec.Name.IndexOf("Detail", StringComparison.OrdinalIgnoreCase) >= 0 ||
                        sec.Name.Equals("Section3", StringComparison.OrdinalIgnoreCase))
                    {
                        sec.SectionFormat.EnableSuppress = hideDetailsTable;
                    }
                }
            }
            catch { }
        }
    }
}
