using System;
using System.Data;
using System.Data.SqlClient;

namespace Lab_14.DAL
{
    /// <summary>
    /// Data Access Layer cho các báo cáo - Lab 14
    /// Mở rộng từ Lab 13: thêm lọc theo khoa, lọc theo khoảng điểm, Top N, đăng ký theo học kỳ
    /// </summary>
    public class BaoCaoDAL
    {
        // =============================================
        // Kế thừa từ Lab 13: Lấy dữ liệu báo cáo sinh viên
        // =============================================
        public DataTable GetStudentReportData()
        {
            DataTable table = new DataTable("vw_BaoCaoSinhVien");
            using (SqlConnection conn = DbConnectionFactory.Create())
            using (SqlDataAdapter adapter = new SqlDataAdapter(
                "SELECT * FROM vw_BaoCaoSinhVien ORDER BY TenKhoa, HoTen", conn))
            {
                adapter.Fill(table);
            }
            return table;
        }

        // =============================================
        // Kế thừa từ Lab 13: Lấy dữ liệu báo cáo khoa
        // =============================================
        public DataTable GetKhoaReportData()
        {
            DataTable table = new DataTable("vw_BaoCaoKhoa");
            using (SqlConnection conn = DbConnectionFactory.Create())
            using (SqlDataAdapter adapter = new SqlDataAdapter(
                "SELECT * FROM vw_BaoCaoKhoa ORDER BY TenKhoa", conn))
            {
                adapter.Fill(table);
            }
            return table;
        }

        // =============================================
        // Kế thừa từ Lab 13: Lấy dữ liệu báo cáo học phần
        // =============================================
        public DataTable GetHocPhanReportData()
        {
            DataTable table = new DataTable("vw_BaoCaoHocPhan");
            using (SqlConnection conn = DbConnectionFactory.Create())
            using (SqlDataAdapter adapter = new SqlDataAdapter(
                "SELECT * FROM vw_BaoCaoHocPhan ORDER BY TenHP", conn))
            {
                adapter.Fill(table);
            }
            return table;
        }

        // =============================================
        // Bài 1 (Lab 14): Lấy danh sách sinh viên theo khoa
        // =============================================
        /// <summary>
        /// Lấy sinh viên thuộc một khoa cụ thể (truy vấn tham số hóa)
        /// </summary>
        public DataTable GetStudentsByDepartment(string maKhoa)
        {
            DataTable table = new DataTable("vw_BaoCaoSinhVien");
            const string sql = @"SELECT * FROM vw_BaoCaoSinhVien 
                                 WHERE MaKhoa = @MaKhoa 
                                 ORDER BY HoTen";
            using (SqlConnection conn = DbConnectionFactory.Create())
            using (SqlDataAdapter adapter = new SqlDataAdapter(sql, conn))
            {
                adapter.SelectCommand.Parameters.Add("@MaKhoa", SqlDbType.NVarChar, 20).Value = maKhoa;
                adapter.Fill(table);
            }
            return table;
        }

        // =============================================
        // Bài 1: Lấy danh sách khoa cho ComboBox
        // =============================================
        /// <summary>
        /// Lấy danh sách khoa (MaKhoa, TenKhoa) để hiển thị trên ComboBox
        /// </summary>
        public DataTable GetDanhSachKhoa()
        {
            DataTable table = new DataTable("DanhSachKhoa");
            using (SqlConnection conn = DbConnectionFactory.Create())
            using (SqlDataAdapter adapter = new SqlDataAdapter(
                "SELECT MaKhoa, TenKhoa FROM Khoa ORDER BY TenKhoa", conn))
            {
                adapter.Fill(table);
            }
            return table;
        }

        // =============================================
        // Bài 4: Lọc sinh viên theo khoảng điểm
        // =============================================
        /// <summary>
        /// Lấy sinh viên theo khoảng điểm TB [min, max]
        /// </summary>
        public DataTable GetByScoreRange(decimal min, decimal max)
        {
            const string sql = @"SELECT * FROM vw_BaoCaoSinhVien
                                 WHERE DiemTB BETWEEN @Min AND @Max
                                 ORDER BY DiemTB DESC";
            using (SqlConnection conn = DbConnectionFactory.Create())
            using (SqlDataAdapter ad = new SqlDataAdapter(sql, conn))
            {
                ad.SelectCommand.Parameters.Add("@Min", SqlDbType.Decimal).Value = min;
                ad.SelectCommand.Parameters.Add("@Max", SqlDbType.Decimal).Value = max;
                DataTable t = new DataTable("vw_BaoCaoSinhVien");
                ad.Fill(t);
                return t;
            }
        }

        // =============================================
        // Bài 6: Top N sinh viên theo điểm
        // =============================================
        /// <summary>
        /// Lấy Top N sinh viên có điểm TB cao nhất (tùy chọn theo khoa)
        /// </summary>
        public DataTable GetTopStudents(int topN, string maKhoa = null)
        {
            string sql;
            if (string.IsNullOrEmpty(maKhoa) || maKhoa == "ALL")
            {
                sql = string.Format(
                    @"SELECT TOP {0} * FROM vw_BaoCaoSinhVien ORDER BY DiemTB DESC", topN);
            }
            else
            {
                sql = string.Format(
                    @"SELECT TOP {0} * FROM vw_BaoCaoSinhVien WHERE MaKhoa = @MaKhoa ORDER BY DiemTB DESC", topN);
            }

            DataTable table = new DataTable("vw_BaoCaoSinhVien");
            using (SqlConnection conn = DbConnectionFactory.Create())
            using (SqlDataAdapter adapter = new SqlDataAdapter(sql, conn))
            {
                if (!string.IsNullOrEmpty(maKhoa) && maKhoa != "ALL")
                {
                    adapter.SelectCommand.Parameters.Add("@MaKhoa", SqlDbType.NVarChar, 20).Value = maKhoa;
                }
                adapter.Fill(table);
            }
            return table;
        }

        // =============================================
        // Bài 7: Đăng ký theo học kỳ
        // =============================================
        /// <summary>
        /// Lấy dữ liệu đăng ký học phần nhóm theo học kỳ
        /// </summary>
        public DataTable GetDangKyTheoHocKy()
        {
            DataTable table = new DataTable("vw_BaoCaoDangKyHocKy");
            const string sql = @"SELECT 
                                    dk.HocKy, 
                                    hp.MaHP, 
                                    hp.TenHP, 
                                    hp.SoTinChi,
                                    COUNT(dk.MaSV) AS SoLuotDangKy,
                                    AVG(dk.Diem) AS DiemTrungBinh,
                                    CAST(dk.HocKy AS NVARCHAR(20)) AS MaKhoa,
                                    N'Học kỳ ' + CAST(dk.HocKy AS NVARCHAR(10)) AS TenKhoa,
                                    hp.MaHP AS MaSV,
                                    hp.TenHP AS HoTen,
                                    AVG(dk.Diem) AS DiemTB,
                                    COUNT(dk.MaSV) AS SoLuongSV,
                                    CAST(GETDATE() AS DATETIME) AS NgaySinh,
                                    N'Học phần' AS GioiTinh,
                                    N'' AS Email
                                 FROM DangKy dk
                                 JOIN HocPhan hp ON dk.MaHP = hp.MaHP
                                 GROUP BY dk.HocKy, hp.MaHP, hp.TenHP, hp.SoTinChi
                                 ORDER BY dk.HocKy, hp.TenHP";
            using (SqlConnection conn = DbConnectionFactory.Create())
            using (SqlDataAdapter adapter = new SqlDataAdapter(sql, conn))
            {
                adapter.Fill(table);
            }
            return table;
        }

        // =============================================
        // Bài 8: Dữ liệu cho biểu đồ sinh viên theo khoa
        // =============================================
        /// <summary>
        /// Lấy số lượng sinh viên theo khoa (cho biểu đồ)
        /// </summary>
        public DataTable GetSinhVienTheoKhoaChart()
        {
            DataTable table = new DataTable("vw_BaoCaoSinhVien");
            const string sql = @"SELECT k.TenKhoa, COUNT(sv.MaSV) AS SoLuongSV
                                 FROM Khoa k
                                 LEFT JOIN SinhVien sv ON k.MaKhoa = sv.MaKhoa
                                 GROUP BY k.TenKhoa
                                 ORDER BY k.TenKhoa";
            using (SqlConnection conn = DbConnectionFactory.Create())
            using (SqlDataAdapter adapter = new SqlDataAdapter(sql, conn))
            {
                adapter.Fill(table);
            }
            return table;
        }

        // =============================================
        // Dữ liệu phân bố xếp loại (cho biểu đồ)
        // =============================================
        /// <summary>
        /// Lấy phân bố xếp loại sinh viên (cho biểu đồ)
        /// </summary>
        public DataTable GetPhanBoXepLoai()
        {
            DataTable table = new DataTable("vw_BaoCaoSinhVien");
            const string sql = @"SELECT 
                CASE 
                    WHEN DiemTB >= 9 THEN N'Xuất sắc'
                    WHEN DiemTB >= 8 THEN N'Giỏi'
                    WHEN DiemTB >= 6.5 THEN N'Khá'
                    WHEN DiemTB >= 5 THEN N'Trung bình'
                    ELSE N'Yếu'
                END AS XepLoai,
                COUNT(*) AS SoLuong
                FROM vw_BaoCaoSinhVien
                GROUP BY 
                    CASE 
                        WHEN DiemTB >= 9 THEN N'Xuất sắc'
                        WHEN DiemTB >= 8 THEN N'Giỏi'
                        WHEN DiemTB >= 6.5 THEN N'Khá'
                        WHEN DiemTB >= 5 THEN N'Trung bình'
                        ELSE N'Yếu'
                    END
                ORDER BY MIN(DiemTB) DESC";
            using (SqlConnection conn = DbConnectionFactory.Create())
            using (SqlDataAdapter adapter = new SqlDataAdapter(sql, conn))
            {
                adapter.Fill(table);
            }
            return table;
        }
    }
}
