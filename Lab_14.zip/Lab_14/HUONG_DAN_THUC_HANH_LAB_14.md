# HƯỚNG DẪN THỰC HÀNH LAB 14
## LẬP TRÌNH .NET (IT3212) - CRYSTAL REPORTS NÂNG CAO

---

### MỤC LỤC
1. [Cấu trúc dự án Lab 14](#1-cấu-trúc-dự-án-lab-14)
2. [Cơ sở dữ liệu SQL Server](#2-cơ-sở-dữ-liệu-sql-server)
3. [Thiết kế trong Crystal Reports Designer](#3-thiết-kế-trong-crystal-reports-designer)
   - 3.1. Parameter Fields (`pTenKhoa`, `pNgayLap`)
   - 3.2. Nhóm dữ liệu theo khoa (Group Header/Footer)
   - 3.3. Thống kê điểm trung bình, Max, Min và Formula `@XepLoai`
   - 3.4. Chèn biểu đồ vào báo cáo (Chart Expert)
4. [Danh sách các Form chức năng chạy qua Crystal Reports](#4-danh-sách-các-form-chức-năng)
5. [Hướng dẫn chạy ứng dụng trong Visual Studio](#5-hướng-dẫn-chạy-ứng-dụng)

---

### 1. CẤU TRÚC DỰ ÁN LAB 14

```
Lab_14/
├── Lab_14.sln                   # Solution mở bằng Visual Studio 2022
├── HUONG_DAN_THUC_HANH_LAB_14.md # Tài liệu hướng dẫn
├── SQL/
│   └── Views_And_SampleData.sql # Script tạo CSDL, bảng, dữ liệu và các View
└── Lab_14/
    ├── Lab_14.csproj            # File dự án C# WinForms .NET Framework 4.8
    ├── Lab_14.csproj.user       # Đường dẫn Crystal Reports runtime
    ├── App.config               # Chuỗi kết nối CSDL
    ├── Program.cs               # Điểm khởi chạy
    ├── DAL/
    │   ├── DbConnectionFactory.cs # Kết nối CSDL SQL Server
    │   └── BaoCaoDAL.cs           # Truy vấn dữ liệu cho các báo cáo
    ├── Forms/
    │   ├── frmMain.cs             # Giao diện chính (không menubar, không chữ nhỏ, nút không icon)
    │   ├── frmBaoCaoSVTheoKhoa.cs # Bài 1, 2, 3, 5: Báo cáo SV theo khoa qua Crystal Reports
    │   ├── frmBaoCaoTheoKhoangDiem.cs # Bài 4: Báo cáo khoảng điểm qua Crystal Reports
    │   ├── frmBaoCaoTopSV.cs      # Bài 6: Báo cáo Top N SV qua Crystal Reports
    │   ├── frmBaoCaoDangKyHK.cs   # Bài 7: Báo cáo ĐK học kỳ qua Crystal Reports
    │   ├── frmBaoCaoBieuDo.cs     # Bài 8: Báo cáo có biểu đồ qua Crystal Reports
    │   ├── frmXuatDataGridView.cs # Bài 9: Lọc và xuất DataGridView sang Excel
    │   ├── frmTrungTamBaoCao.cs   # Bài 10: Trung tâm báo cáo tích hợp Crystal Reports
    │   ├── frmBaoCaoSinhVien.cs   # Lab 13: Báo cáo toàn bộ sinh viên
    │   ├── frmBaoCaoKhoa.cs       # Lab 13: Báo cáo khoa
    │   └── frmBaoCaoHocPhan.cs    # Lab 13: Báo cáo học phần
    └── Reports/
        ├── rptSinhVien.rpt / .cs   # Crystal Report: Sinh viên
        ├── rptKhoa.rpt / .cs       # Crystal Report: Khoa
        ├── rptHocPhan.rpt / .cs    # Crystal Report: Học phần
        ├── rptDangKyHocKy.rpt / .cs# Crystal Report: Đăng ký học phần
        └── rptBieuDo.rpt / .cs     # Crystal Report: Biểu đồ
```

---

### 2. CƠ SỞ DỮ LIỆU SQL SERVER

1. Mở **SQL Server Management Studio (SSMS)**.
2. Mở file `Lab_14/SQL/Views_And_SampleData.sql`.
3. Bấm **Execute (F5)** để thực thi tạo CSDL `QLSinhVien`, bảng `Khoa`, `SinhVien`, `HocPhan`, `DangKy`, nạp dữ liệu mẫu và tạo các View báo cáo:
   - `vw_BaoCaoSinhVien`
   - `vw_BaoCaoKhoa`
   - `vw_BaoCaoHocPhan`
   - `vw_BaoCaoDangKyHocKy`

---

### 3. THIẾT KẾ TRONG CRYSTAL REPORTS DESIGNER

Mở các file `.rpt` trong Visual Studio để cấu hình:

#### 3.1. Parameter Fields (Bài 1)
- Trong **Field Explorer**, chuột phải vào **Parameter Fields** -> **New...**
- Tạo `pTenKhoa` (Type: String) và `pNgayLap` (Type: DateTime).
- Kéo 2 tham số này vào phần **Report Header**.

#### 3.2. Nhóm dữ liệu theo khoa (Bài 2)
- Chọn menu **Report** -> **Group Expert...** -> Chọn trường `SinhVienReport.TenKhoa`.
- **Group Header #1**: Thêm Formula `@TieuDeNhom`: `"Khoa: " & {SinhVienReport.TenKhoa}`.
- **Group Footer #1**: Chuột phải trường `MaSV` -> **Insert Summary...** -> Hàm **Count** theo nhóm `TenKhoa`.

#### 3.3. Thống kê điểm trung bình và Formula `@XepLoai` (Bài 3)
- Chuột phải trường `DiemTB` -> **Insert Summary...** -> Chọn **Average**, **Maximum**, **Minimum**.
- Tạo Formula `@XepLoai` trong **Formula Workshop**:
  ```crystal
  If {SinhVienReport.DiemTB} >= 9 Then "Xuất sắc"
  Else If {SinhVienReport.DiemTB} >= 8 Then "Giỏi"
  Else If {SinhVienReport.DiemTB} >= 6.5 Then "Khá"
  Else If {SinhVienReport.DiemTB} >= 5 Then "Trung bình"
  Else "Yếu"
  ```
- Kéo `@XepLoai` vào phần **Details**.

#### 3.4. Chèn biểu đồ vào báo cáo (Bài 8)
- Trong Report Designer: Chuột phải vào **Report Header** (hoặc **Report Footer**) -> **Insert** -> **Chart...**
- Chọn dạng biểu đồ **Bar Chart** (Biểu đồ cột) hoặc **Pie Chart** (Biểu đồ tròn).
- Tại tab **Data**: Chọn trường nhóm (`TenKhoa`) và trường giá trị (`Count of MaSV`).

---

### 4. DANH SÁCH CÁC FORM CHỨC NĂNG (TẤT CẢ QUA CRYSTAL REPORTS)

| Chức năng | Form thực hiện | Báo cáo Crystal Reports sử dụng |
|---|---|---|
| **Bài 1**: Báo cáo theo tham số khoa | `frmBaoCaoSVTheoKhoa` | `rptSinhVien.rpt` qua `CrystalReportViewer` (truyền `pTenKhoa`, `pNgayLap`) |
| **Bài 2, 3**: Nhóm theo khoa & Thống kê | `frmBaoCaoSVTheoKhoa` | `rptSinhVien.rpt` với Group Header/Footer, Summary và Formula `@XepLoai` |
| **Bài 4**: Báo cáo theo khoảng điểm | `frmBaoCaoTheoKhoangDiem` | `rptSinhVien.rpt` qua `CrystalReportViewer` (lọc `DiemTB BETWEEN @Min AND @Max`) |
| **Bài 5**: Xuất Crystal sang Excel | Mọi form báo cáo | Sử dụng `_report.ExportToDisk(ExportFormatType.ExcelWorkbook, ...)` |
| **Bài 6**: Báo cáo Top N sinh viên | `frmBaoCaoTopSV` | `rptSinhVien.rpt` qua `CrystalReportViewer` (truy vấn `TOP N ... ORDER BY DiemTB DESC`) |
| **Bài 7**: Báo cáo ĐK theo học kỳ | `frmBaoCaoDangKyHK` | `rptDangKyHocKy.rpt` qua `CrystalReportViewer` |
| **Bài 8**: Báo cáo có biểu đồ | `frmBaoCaoBieuDo` | `rptBieuDo.rpt` qua `CrystalReportViewer` |
| **Bài 9**: Xuất DataGridView sang Excel | `frmXuatDataGridView` | Lọc dữ liệu trên DataGridView và xuất định dạng Excel chuẩn giữ tiêu đề, ngày, số |
| **Bài 10**: Trung tâm báo cáo | `frmTrungTamBaoCao` | Chọn loại báo cáo, nạp vào `CrystalReportViewer` và xuất PDF / Excel |

---

### 5. HƯỚNG DẪN CHẠY ỨNG DỤNG

1. Mở file `Lab_14.sln` trong **Visual Studio 2022**.
2. Chọn cấu hình build: **Debug | x64** hoặc **Debug | AnyCPU** (phù hợp với phiên bản runtime Crystal Reports đã cài trên máy).
3. Bấm **Start (F5)** để chạy chương trình. Giao diện chính `frmMain` hiển thị tiêu đề tinh gọn và các nút chức năng trực tiếp.
