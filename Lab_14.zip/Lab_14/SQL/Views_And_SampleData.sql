USE [master]
GO

-- Tạo cơ sở dữ liệu nếu chưa có
IF NOT EXISTS (SELECT 1 FROM sys.databases WHERE name = N'QLSinhVien')
BEGIN
    CREATE DATABASE [QLSinhVien];
END
GO

USE [QLSinhVien]
GO

-- ========================================================
-- 1. BẢNG KHOA
-- ========================================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = N'Khoa')
BEGIN
    CREATE TABLE [dbo].[Khoa] (
        [MaKhoa]  NVARCHAR(20)  NOT NULL PRIMARY KEY,
        [TenKhoa] NVARCHAR(100) NOT NULL
    );
END
GO

-- ========================================================
-- 2. BẢNG SINH VIÊN
-- ========================================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = N'SinhVien')
BEGIN
    CREATE TABLE [dbo].[SinhVien] (
        [MaSV]     NVARCHAR(20)  NOT NULL PRIMARY KEY,
        [HoTen]    NVARCHAR(100) NOT NULL,
        [NgaySinh] DATETIME      NULL,
        [GioiTinh] BIT           NULL, -- 1: Nam, 0: Nữ
        [MaKhoa]   NVARCHAR(20)  NOT NULL FOREIGN KEY REFERENCES [dbo].[Khoa]([MaKhoa]),
        [DiemTB]   DECIMAL(4, 2) NULL,
        [Email]    NVARCHAR(100) NULL
    );
END
GO

-- ========================================================
-- 3. BẢNG HỌC PHẦN
-- ========================================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = N'HocPhan')
BEGIN
    CREATE TABLE [dbo].[HocPhan] (
        [MaHP]     NVARCHAR(20)  NOT NULL PRIMARY KEY,
        [TenHP]    NVARCHAR(100) NOT NULL,
        [SoTinChi] INT           NOT NULL DEFAULT 3
    );
END
GO

-- ========================================================
-- 4. BẢNG ĐĂNG KÝ
-- ========================================================
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = N'DangKy')
BEGIN
    CREATE TABLE [dbo].[DangKy] (
        [MaSV]   NVARCHAR(20)  NOT NULL FOREIGN KEY REFERENCES [dbo].[SinhVien]([MaSV]),
        [MaHP]   NVARCHAR(20)  NOT NULL FOREIGN KEY REFERENCES [dbo].[HocPhan]([MaHP]),
        [HocKy]  INT           NOT NULL,
        [Diem]   DECIMAL(4, 2) NULL,
        PRIMARY KEY ([MaSV], [MaHP], [HocKy])
    );
END
GO

-- ========================================================
-- DỮ LIỆU MẪU: KHOA
-- ========================================================
IF NOT EXISTS (SELECT 1 FROM [dbo].[Khoa] WHERE [MaKhoa] = N'CNTT')
BEGIN
    INSERT INTO [dbo].[Khoa] ([MaKhoa], [TenKhoa]) VALUES 
    (N'CNTT',  N'Công nghệ Thông tin'),
    (N'KT',    N'Kinh tế'),
    (N'NN',    N'Ngoại ngữ'),
    (N'DTVT',  N'Điện tử Viễn thông'),
    (N'QTKD',  N'Quản trị Kinh doanh');
END
GO

-- ========================================================
-- DỮ LIỆU MẪU: SINH VIÊN (đa dạng điểm số phục vụ Bài 3, 4, 6)
-- ========================================================
IF NOT EXISTS (SELECT 1 FROM [dbo].[SinhVien] WHERE [MaSV] = N'SV001')
BEGIN
    INSERT INTO [dbo].[SinhVien] ([MaSV], [HoTen], [NgaySinh], [GioiTinh], [MaKhoa], [DiemTB], [Email]) VALUES
    (N'SV001', N'Nguyễn Văn An',       '2003-01-15', 1, N'CNTT',  8.75, N'an.nv@eaut.edu.vn'),
    (N'SV002', N'Trần Thị Bình',      '2003-05-20', 0, N'CNTT',  9.20, N'binh.tt@eaut.edu.vn'),
    (N'SV003', N'Lê Hoàng Cường',     '2002-11-10', 1, N'KT',    7.60, N'cuong.lh@eaut.edu.vn'),
    (N'SV004', N'Phạm Minh Dũng',     '2003-03-25', 1, N'CNTT',  6.40, N'dung.pm@eaut.edu.vn'),
    (N'SV005', N'Hoàng Thị Giang',    '2003-08-14', 0, N'NN',    8.10, N'giang.ht@eaut.edu.vn'),
    (N'SV006', N'Đặng Văn Hùng',      '2002-12-05', 1, N'DTVT',  5.20, N'hung.dv@eaut.edu.vn'),
    (N'SV007', N'Vũ Thị Kim',         '2003-04-18', 0, N'QTKD',  9.50, N'kim.vt@eaut.edu.vn'),
    (N'SV008', N'Bùi Thanh Long',     '2003-07-22', 1, N'KT',    4.80, N'long.bt@eaut.edu.vn'),
    (N'SV009', N'Ngô Mai Phương',     '2003-09-30', 0, N'CNTT',  7.90, N'phuong.nm@eaut.edu.vn'),
    (N'SV010', N'Đỗ Quốc Tuấn',       '2002-06-12', 1, N'QTKD',  8.40, N'tuan.dq@eaut.edu.vn');
END
GO

-- ========================================================
-- DỮ LIỆU MẪU: HỌC PHẦN
-- ========================================================
IF NOT EXISTS (SELECT 1 FROM [dbo].[HocPhan] WHERE [MaHP] = N'HP001')
BEGIN
    INSERT INTO [dbo].[HocPhan] ([MaHP], [TenHP], [SoTinChi]) VALUES 
    (N'HP001', N'Lập trình .NET',       3),
    (N'HP002', N'Cơ sở dữ liệu',         3),
    (N'HP003', N'Mạng máy tính',        2),
    (N'HP004', N'Hệ điều hành',         3),
    (N'HP005', N'Trí tuệ nhân tạo',     3),
    (N'HP006', N'Kinh tế vi mô',        2);
END
GO

-- ========================================================
-- DỮ LIỆU MẪU: ĐĂNG KÝ (phục vụ Bài 7: Đăng ký theo học kỳ)
-- ========================================================
IF NOT EXISTS (SELECT 1 FROM [dbo].[DangKy] WHERE [MaSV] = N'SV001' AND [MaHP] = N'HP001')
BEGIN
    INSERT INTO [dbo].[DangKy] ([MaSV], [MaHP], [HocKy], [Diem]) VALUES 
    (N'SV001', N'HP001', 1, 8.50),
    (N'SV001', N'HP002', 1, 7.00),
    (N'SV002', N'HP001', 1, 9.00),
    (N'SV002', N'HP003', 2, 6.50),
    (N'SV003', N'HP004', 1, 7.50),
    (N'SV004', N'HP001', 1, 6.00),
    (N'SV004', N'HP002', 2, 7.00),
    (N'SV005', N'HP006', 1, 8.00),
    (N'SV006', N'HP003', 2, 5.50),
    (N'SV007', N'HP006', 1, 9.50),
    (N'SV009', N'HP001', 1, 8.00),
    (N'SV009', N'HP005', 2, 8.50),
    (N'SV010', N'HP006', 1, 8.50);
END
GO

-- ========================================================
-- VIEWS BÁO CÁO
-- ========================================================

-- View báo cáo sinh viên (Lab 13 + Lab 14 Bài 1, 2, 3, 4, 6, 8, 9)
CREATE OR ALTER VIEW [dbo].[vw_BaoCaoSinhVien]
AS
SELECT sv.MaSV, sv.HoTen, sv.NgaySinh,
       CASE sv.GioiTinh WHEN 1 THEN N'Nam' ELSE N'Nữ' END AS GioiTinh,
       k.MaKhoa, k.TenKhoa, sv.DiemTB, sv.Email
FROM SinhVien sv
JOIN Khoa k ON sv.MaKhoa = k.MaKhoa;
GO

-- View báo cáo danh sách khoa + số lượng SV
CREATE OR ALTER VIEW [dbo].[vw_BaoCaoKhoa]
AS
SELECT k.MaKhoa, k.TenKhoa,
       COUNT(sv.MaSV) AS SoLuongSV
FROM Khoa k
LEFT JOIN SinhVien sv ON k.MaKhoa = sv.MaKhoa
GROUP BY k.MaKhoa, k.TenKhoa;
GO

-- View báo cáo danh sách học phần
CREATE OR ALTER VIEW [dbo].[vw_BaoCaoHocPhan]
AS
SELECT hp.MaHP, hp.TenHP, hp.SoTinChi
FROM HocPhan hp;
GO

-- View báo cáo đăng ký học phần theo học kỳ (Lab 14 Bài 7)
CREATE OR ALTER VIEW [dbo].[vw_BaoCaoDangKyHocKy]
AS
SELECT dk.HocKy, hp.MaHP, hp.TenHP, hp.SoTinChi,
       COUNT(dk.MaSV) AS SoLuotDangKy,
       AVG(dk.Diem) AS DiemTrungBinh
FROM DangKy dk
JOIN HocPhan hp ON dk.MaHP = hp.MaHP
GROUP BY dk.HocKy, hp.MaHP, hp.TenHP, hp.SoTinChi;
GO
